n=raw_input("enter com ma sperated string ")

li=n.split(',')
li.sort()

	
print li

