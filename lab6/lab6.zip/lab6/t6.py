n=raw_input("enter a string ")

li=n.split(' ')

newli=[]

for i in li:
	if i in newli:
		continue
	newli.append(i)
		

newli.sort();

for i in newli:
	print i.lower(),
