n=raw_input("enter comma sperated numbers ")

li=n.split(',')
li2=tuple(li)

	
print li
print li2
