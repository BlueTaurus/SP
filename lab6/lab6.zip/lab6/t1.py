l1=range(2000,3200)

for n in l1:
	
	if ((n%7 == 0) and (n%5 != 0) ):
		print  '{0},'.format(n),
