n=raw_input("enter a string ")

print n.upper()

	


