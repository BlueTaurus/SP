n=raw_input("enter a string ")


li=range(0,int(len(n)))

no=0
al=0

li2=['1', '2', '3', '4', '5', '6', '7', '8', '9' ] 
l1='abcdefghijklmnopqrstuvwxyz'
print li2

for i in li:
	if n[i] in li2:
		no+=1
		continue
	if n[i] in l1:
		al+=1
		continue
	
	
print 'alphabets = {0} \n numbers ={1}'.format(al,no)
		
