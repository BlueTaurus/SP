n=raw_input("enter range ")

li=range(1,int(n)+1)
left={}
i=1;

for i in li:
	left[i]=i*i
	
print left
