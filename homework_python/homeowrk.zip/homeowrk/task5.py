import sum

if __name__=="__main__":
	ListOfName=["hi sir","what are you","doing"]
	print sum.sum(ListOfName)
