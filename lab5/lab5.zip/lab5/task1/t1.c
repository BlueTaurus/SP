#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("%d is the real user id\n",(long)getuid());
	printf("%d is the effective user id\n",(long)geteuid());
	printf("%d is the real group id\n",(long)getgid());
	printf("%d is the real effective group id\n",(long)getegid());
	return 0;
}
