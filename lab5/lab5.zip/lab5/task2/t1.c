#include<stdio.h>
#include<unistd.h>
int main()
{
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;
	
	getresuid(&ruid, &euid, &suid);
	getresgid(&rgid, &egid, &sgid);
	
	printf("%d is the real user id\n",(long)ruid);
	printf("%d is the real group id\n",(long)rgid);
	printf("%d is the effective user id\n",(long)euid);
	printf("%d is the effective group id\n",(long)egid);
	printf("%d is the saved user id\n",(long)suid);
	printf("%d is the saved group id\n",(long)sgid);

	if(setuid(501)!=-1)
	{
		
	getresuid(&ruid, &euid, &suid);
	getresgid(&rgid, &egid, &sgid);
	
	printf("%d is the real user id\n",(long)ruid);
	printf("%d is the real group id\n",(long)rgid);
	printf("%d is the effective user id\n",(long)euid);
	printf("%d is the effective group id\n",(long)egid);
	printf("%d is the saved user id\n",(long)suid);
	printf("%d is the saved group id\n",(long)sgid);	
	}
	else
	{
		printf("\naccess denied\n");
	}
	
	return 0;
}
