#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{

	int cpid;
	
	printf("\n and then the fork happened\n\n");
	cpid =fork();
	if(cpid==0)
	{	
		execlp("bash", "mybash", NULL);
		printf("\n exec failed\n\n");
	}
	else
	{
		wait();
			printf("\n main ended\n\n");

		
	}
}


