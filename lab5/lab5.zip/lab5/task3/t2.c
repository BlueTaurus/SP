#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
	printf("%d is the pid of the main\n",(long)getpid());
	printf("%d is the ppid of the main\n",(long)getppid());
	int cpid;
	
	printf("\n and then the fork happened\n\n");
	cpid =fork();
	if(cpid==0)
	{
		printf("\n info about child\n\n");
	printf("%d is the pid of child\n",(long)getpid());
	printf("%d is the ppid of the child\n",(long)getppid());
	printf("%d is the cpid of the child\n",(long)cpid);
	exit(-3);
	}
	else
	{
		int status;
	wait(&status);
	if(WIFEXITED(status))
	{
	printf("exit status of the process :%d\n",WEXITSTATUS(status));
	}
	printf("\n info about parent\n\n");
	printf("%d is the pid of parent\n",(long)getpid());
	printf("%d is the ppid of the parent\n",(long)getppid());	
	printf("%d is the cpid of the parent\n",(long)cpid);
	}
}
